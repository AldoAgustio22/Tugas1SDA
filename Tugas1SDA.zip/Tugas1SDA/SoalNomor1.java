package Tugas1SDA;

public class SoalNomor1 {
	public static void main(String[] args) {
		String nama[] = {"A","L","D","O"};
		
		// Soal Nomor 1 
		// isEmpty
		
		System.out.println(nama[0].isEmpty());
		System.out.println(nama[1].isEmpty());
		System.out.println(nama[2].isEmpty());
		System.out.println(nama[3].isEmpty());
	}
}