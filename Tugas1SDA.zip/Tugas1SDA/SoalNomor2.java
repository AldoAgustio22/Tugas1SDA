package Tugas1SDA;

public class SoalNomor2 {
	public static void main(String[] args) {
	    String nama[] = {"A","L","D","O"};
	    
	    // Soal Nomor 2
	    // size()
	    
	    String size0 = "A";
	    String size1 = "L";
	    String size2 = "D";
	    String size3 = "O";
	    
	    System.out.println("Karakter size0: "+nama.length);
        System.out.println("Karakter size1: "+nama.length);
        System.out.println("Karakter size2: "+nama.length);
        System.out.println("Karakter size3: "+nama.length);
	}
}