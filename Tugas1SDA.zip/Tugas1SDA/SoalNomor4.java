package Tugas1SDA;

import java.util.ArrayList;

public class SoalNomor4 {
	public static void main(String[] args) {
		ArrayList<String> nama = new ArrayList<String>();
	    nama.add("A");
	    nama.add("L");
	    nama.add("D");
	    nama.add("O");
	    
	    //Soal Nomor 4
	    //indexOf(a), indexOf(c), indexOf(q)

	    System.out.println(nama.indexOf("a"));
	    System.out.println(nama.indexOf("c"));
	    System.out.println(nama.indexOf("q"));

	    }
	}