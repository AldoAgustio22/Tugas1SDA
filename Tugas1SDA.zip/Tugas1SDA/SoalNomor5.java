package Tugas1SDA;

import java.util.ArrayList;

public class SoalNomor5 {
	public static void main(String[] args) {
		ArrayList<String> nama = new ArrayList<String>();
		nama.add("A");
	    nama.add("L");
	    nama.add("D");
	    nama.add("O");
	    //nama.remove(0);
	    //nama.remove(3);
	    //nama.remove(2);
	    
	   // System.out.println(nama.remove(0));
	   // System.out.println(nama.remove(3));
	   //System.out.println(nama.remove(2));
	   System.out.println("ArrayList sesudah remove:");
	       for(String var2: nama){
	             System.out.println(var2);

	            }
	    
	    }
	}