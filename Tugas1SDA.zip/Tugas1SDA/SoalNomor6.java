package Tugas1SDA;

import java.util.ArrayList;

public class SoalNomor6 {
	public static void main(String[] args) {
		ArrayList<String> nama = new ArrayList<String>();
		nama.add("A");
	    nama.add("L");
	    nama.add("D");
	    nama.add("O");
	    
	    nama.add(0,"e");
	    System.out.println("menambahkan string e " + nama);
	    nama.add("2,f");
	    System.out.println("menambahkan string f " + nama);
	    nama.add("3,g");
	    System.out.println("menambahkan string g " + nama);
	    nama.add("4,h");
	    System.out.println("menambahkan string h " + nama);
	    nama.add("6,h");
	    System.out.println("menambahkan string h " + nama);
	    nama.add("-3,j");
	    System.out.println("menambahkan string j " + nama);
	    
	}

}
